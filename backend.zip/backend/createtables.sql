-- Create database
CREATE DATABASE baydderc_bayadder 
WITH TEMPLATE = template0 
ENCODING = 'UTF8';

-- Connect to the database
\connect baydderc_bayadder

-- Create function for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create tables
CREATE TABLE admin_users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE sections (
    id SERIAL PRIMARY KEY,
    title_en VARCHAR(255) NOT NULL,
    title_ar VARCHAR(255),
    description_en TEXT,
    description_ar TEXT,
    image VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    title VARCHAR(255)
);

CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    title_en VARCHAR(255) NOT NULL,
    title_ar VARCHAR(255),
    description_en TEXT,
    description_ar TEXT,
    image VARCHAR(255),
    section_id INTEGER,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE company (
    id SERIAL PRIMARY KEY,
    name_en VARCHAR(255) NOT NULL,
    name_ar VARCHAR(255) NOT NULL,
    about_en TEXT,
    about_ar TEXT,
    about_paragraph1_en TEXT,
    about_paragraph1_ar TEXT,
    about_paragraph2_en TEXT,
    about_paragraph2_ar TEXT,
    email VARCHAR(255),
    phone VARCHAR(50),
    address_en VARCHAR(255),
    address_ar VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    title_en VARCHAR(255) NOT NULL,
    title_ar VARCHAR(255),
    image VARCHAR(255),
    category_id INTEGER,
    section_id INTEGER,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE services (
    id SERIAL PRIMARY KEY,
    title_en VARCHAR(255) NOT NULL,
    title_ar VARCHAR(255) NOT NULL,
    description_en TEXT,
    description_ar TEXT,
    image VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Insert data
INSERT INTO admin_users (username, password_hash) VALUES 
('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9');

INSERT INTO sections (title_en, title_ar, image, title) VALUES 
('Fertilizers & Nutrients Section', ' قسم الأسمدة والمغذيات العضوية', 'images/fertilizers/fertilierss.jpeg', 'fertilizers'),
('Pesticides Section', 'قسم المبيدات', 'images/pesticits/pesticits.jpeg', 'pesticides'),
('Seeds Section', 'قسم البذور', 'images/seeds/seeds.jpeg', 'seeds'),
('Nutrients Section', 'قسم المغذيات العضوية', 'images/fertilizers/fertilierss.jpeg', 'Nutrients');

INSERT INTO categories (title_en, title_ar, description_en, image, section_id) VALUES 
('Bavaria', 'بافاريا', 'Premium Bavaria fertilizers', 'images/fertilizers/Bavaria/Bavaria-1.jpeg', 1),
('Seaweeds', 'الطحالب', 'Seaweed-based growth stimulants', 'images/fertilizers/Nutrients/Alga/alga-1.jpg', 4),
('Amino Acids', 'الأحماض الأمينية', 'Essential amino acids for plant development', 'images/fertilizers/Nutrients/Amino Acids/Amino-1.jpeg', 4),
('Kelpak', 'كيلباك', 'Natural kelp extract for plant vitality', 'images/fertilizers/Nutrients/Kelpak/Kelpak1L.jpg', 4),
('Insecticides', 'مبيدات حشرية', 'Targeted insect control', 'images/pesticits/Insecticides/King Chim.jpg', 2),
('Fungicides', 'مبيدات فطرية', 'Effective fungus protection', 'images/pesticits/Fungicides/VitaForm.jpg', 2),
('Nematicides', 'مبيدات الديدان الأسطوانية', 'Soil pest control', 'images/pesticits/Nematicides/Mocazad.jpg', 2),
('Onions', 'بصل', 'High germination onion seeds', 'images/seeds/Onion/Bello.jpg', 3),
('Peas', 'بازلاء', 'Sweet pods, high germination', 'images/seeds/Peas/Afnan Pea.jpg', 3),
('Cucumbers', 'خيار', 'High quality cucumber seeds', 'images/seeds/Cucumber/Fawaz 4002.jpg', 3),
('Watermelons', 'بطيخ', 'Juicy, sweet flesh', 'images/seeds/WaterMelon/Hind.jpg', 3),
('Melons', 'شمام', 'Sweet, fragrant melons', 'images/seeds/Melon/Borhan.jpg', 3),
('Tomatoes', 'طماطم', 'High-yield tomato seeds', 'images/seeds/Tomatoes/Mancera.jpg', 3),
('Lettuce', 'خس', 'Crisp, high-quality lettuce seeds', 'images/seeds/Lettuce/SunLine.jpg', 3),
('Peppers', 'فلفل', 'Sweet and hot pepper varieties', 'images/seeds/Peppers/Express.jpg', 3),
('Cauliflower', 'الزهرة', 'High yield cauliflower seeds', 'images/seeds/Cauliflower/Fujiyama.jpg', 3);

INSERT INTO company (name_en, name_ar, about_en, about_ar, about_paragraph1_en, about_paragraph1_ar, about_paragraph2_en, about_paragraph2_ar, email, phone, address_en, address_ar) VALUES 
('Bayaddrr', 'البيادر', 
'We Are With you till Harvesting!', 
'نحن معك حتى الحصاد!', 
'Bayaddrr is a leading agricultural company with several branches across Libya. We import the best and purest seeds that are resistant to diseases and climate conditions. The company is known for providing exceptional varieties that have gained farmers'' trust and a strong market position in Libya. We also have a testing station to conduct precise tests on seeds, fertilizers, and pesticides before marketing them. These tests are supervised by a team of professional engineers with high expertise and competence. Our team combines traditional agricultural knowledge with advanced technology to deliver results that exceed expectations. We believe in building long-term relationships with our clients and supporting them throughout their agricultural journey.', 
'تُعد شركة البيادر الزراعية من الشركات الرائدة في مجال الزراعة، وتمتلك عدة فروع في مختلف أنحاء ليبيا.نقوم بإستيراد أفضل أنواع البذور والأكثرها نقاوة والمتحملة للامراض والظروف المناخية.تتميز الشركة بتوفير أصناف متميزة نالت رضا الفلاحين، وحظيت بمكانة قوية في السوق الليبي.كما نمتلك محطة تجارب لإجراء اختبارات دقيقة على البذور، الأسمدة، والمبيدات، قبل اعتمادها للتسويق. يشرف على هذه التجارب نخبة من المهندسين المحترفين ذوي الخبرة والكفاءة العالية.', 
'Bayaddrr offers the finest pesticides and fertilizers that are environmentally friendly and effective. We strive to provide comprehensive solutions to agricultural problems and promote awareness about the safe use of pesticides. Our goal is to support farmers'' success and help them increase production at minimal costs.', 
'تقدم شركة البيادر أجود أنواع المبيدات والأسمدة، الآمنة على البيئة وصحة الإنسان، والمتميزة بنتائجها الفعّالة.نسعى دائمًا لتقديم حلول جذرية للمشكلات الزراعية، ونحرص على نشر الوعي حول الاستخدام الآمن للمبيدات.نطمح دومًا إلى دعم نجاح الفلاحين، ومساعدتهم على زيادة الإنتاج بأقل التكاليف.', 
'info@bayadder.com', '+218 91-0029409', 'Libya / Tripoli / Alnoufliyen', 'ليبيا / طرابلس / النوفليين');

INSERT INTO products (title_en, title_ar, image, category_id, section_id) VALUES 
('Bavaria 20.20.20', 'بافاريا 20.20.20', 'images/fertilizers/Bavaria/Bavaria-1.jpeg', 1, 1),
('Bavaria 20.8.40', 'بافاريا 20.8.40', 'images/fertilizers/Bavaria/Bavaria-2.jpg', 1, 1),
('Bayadder600', 'منتج بيادر600 الطحلبي', 'images/fertilizers/Nutrients/Seaweeds/Seaweeds-1.jpg', 2, 4),
('Barakat Onion Seeds', 'بذور بصل بركات', 'https://admin.bayadder.com/uploads/1758433265746.jpg', 8, 3),
('Afnan Pea Seeds', 'بذور بازلاء أفنان', 'images/seeds/Peas/Afnan Pea.jpg', 9, 3),
('Amin Z one 50% Product', 'منتج أمين زد ون 50%', 'images/fertilizers/Nutrients/Amino Acids/Amino-1.jpeg', 3, 4),
('Kelpak 1L', 'منتج كيلباك 1ل', 'images/fertilizers/Nutrients/Kelpak/Kelpak1L.jpg', 4, 4),
('Kelpak 5L', 'منتج كيلباك 5ل', 'images/fertilizers/Nutrients/Kelpak/Kelpak-5L.jpeg', 4, 4),
('King Chim', 'كينج شيم', 'images/pesticits/Insecticides/King Chim.jpg', 5, 2),
('Brituo 50%', 'بريتو 50%', 'images/pesticits/Insecticides/Brituo.jpg', 5, 2),
('Tachtic', 'تاتشيك', 'images/pesticits/Insecticides/Tachtic.jpg', 5, 2),
('Flax', 'فلاكس', 'images/pesticits/Insecticides/Flax.jpg', 5, 2),
('VitaForm', 'فيتافورم', 'images/pesticits/Fungicides/VitaForm.jpg', 6, 2),
('Magico', 'ماجيكو', 'images/pesticits/Magico.jpeg', 6, 2),
('Mocazad', 'موكازاد', 'images/pesticits/Nematicides/Mocazad.jpg', 7, 2),
('Fawaz 4002 Seeds', 'بذور خيار فواز 4002', 'images/seeds/Cucumber/Fawaz 4002.jpg', 10, 3),
('Borhan Onion Seeds', 'بذور بصل برهان', 'images/seeds/Onion/Borhan-ON.jpg', 8, 3),
('Plus Onion Seeds', 'بذور بصل بلس', 'images/seeds/Onion/Plus.jpg', 8, 3),
('Howari Onion Seeds', 'بذور بصل هواري', 'images/seeds/Onion/Howari.jpg', 8, 3),
('Bello Onion Seeds', 'بذور بصل بيلو', 'images/seeds/Onion/Bello.jpg', 8, 3),
('Bebars Seeds', 'بذور خيار بيبارص', 'images/seeds/Cucumber/Bebars.jpg', 10, 3),
('Mohanned Seeds', 'بذور خيار مهند', 'images/seeds/Cucumber/Mohanned.jpg', 10, 3),
('Hind Watermelon Seeds', 'بذور بطيخ هند', 'images/seeds/WaterMelon/Hind.jpg', 11, 3),
('Borhan Melon Seeds', 'بذور شمام برهان', 'images/seeds/Melon/Borhan.jpg', 12, 3),
('Yellow Kanari (Wifak) Seeds', 'بذور شمام وفاق', 'images/seeds/Melon/Wifak.jpg', 12, 3),
('Mancera Tomato Seeds', 'بذور طماطم مانسيرا', 'images/seeds/Tomatoes/Mancera.jpg', 13, 3),
('SunLine Lettuce Seeds', 'بذور خس صن لاين', 'images/seeds/Lettuce/SunLine.jpg', 14, 3),
('Express Bell Pepper Seeds', 'بذور فلفل حلو اكسبريس', 'images/seeds/Peppers/Express.jpg', 15, 3),
('Super Misrati Pepper Seeds', 'بذور فلفل سوبر مصراتي', 'images/seeds/Peppers/Super Mistrati.jpg', 15, 3),
('Makhzum Pepper Seeds', 'بذور فلفل مخزوم', 'images/seeds/Peppers/Makhzum.jpg', 15, 3),
('FujiYama Cauliflower Seeds', 'بذور الزهرة فوجياما', 'images/seeds/Cauliflower/Fujiyama.jpg', 16, 3),
('Kinda Cauliflower Seeds', 'بذور الزهرة كندا', 'images/seeds/Cauliflower/Kinda.jpg', 16, 3),
('KingStar Cauliflower Seeds', 'بذور الزهرة كينج ستар', 'images/seeds/Cauliflower/KingStar.jpg', 16, 3);

INSERT INTO services (title_en, title_ar, description_en, description_ar, image) VALUES 
('Agricultural Consulting', 'الاستشارات الزراعية', 
'Expert guidance on sustainable farming practices, crop management, and agricultural optimization.', 
'توجيه الخبراء في الممارسات الزراعية المستدامة وإدارة المحاصيل وتحسين الزراعة.', 
'images/Services/Agricultural Consulting.jpeg'),
('Technical Support', 'الدعم الفني', 
'24/7 technical assistance for all your farming needs, equipment troubleshooting, and maintenance.', 
'مساعدة فنية على مدار الساعة لجميع احتياجاتك الزراعية واستكشاف أخطاء المعدات وصيانتها.', 
'images/Services/technical-support.jpeg');

-- Add foreign key constraints
ALTER TABLE categories ADD CONSTRAINT categories_section_id_fkey 
FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE;

ALTER TABLE products ADD CONSTRAINT products_section_id_fkey 
FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE;

-- Create triggers
CREATE TRIGGER update_categories_updated_at 
BEFORE UPDATE ON categories 
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_sections_updated_at 
BEFORE UPDATE ON sections 
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();